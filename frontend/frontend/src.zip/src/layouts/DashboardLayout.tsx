import React from 'react'
import Sidebar from './Sidebar'
import TopNavbar from './TopNavbar'

interface Props {
  children?: React.ReactNode
}

export const DashboardLayout: React.FC<Props> = ({ children }) => {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <TopNavbar />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-6">
          <div className="max-w-7xl mx-auto">{children}</div>
        </main>
      </div>
    </div>
  )
}

export default DashboardLayout
