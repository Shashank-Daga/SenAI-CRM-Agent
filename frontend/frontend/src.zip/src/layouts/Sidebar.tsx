import React from 'react'
import { NavLink } from 'react-router-dom'

const items = [
  { to: '/', label: 'Inbox' },
  { to: '/threads', label: 'Threads' },
  { to: '/analytics', label: 'Analytics' },
  { to: '/escalations', label: 'Escalations' },
]

export const Sidebar: React.FC = () => {
  return (
    <aside className="w-60 min-w-[220px] border-r border-gray-200 bg-white/3 p-4 hidden md:block">
      <div className="mb-6">
        <h2 className="text-xl font-bold">Ops</h2>
        <p className="text-xs text-gray-500">Monitoring & triage</p>
      </div>
      <nav className="flex flex-col gap-2">
        {items.map((it) => (
          <NavLink key={it.to} to={it.to} className={({ isActive }) => `px-3 py-2 rounded-md text-sm ${isActive ? 'bg-indigo-600 text-white' : 'text-gray-700 hover:bg-gray-100'}`}>
            {it.label}
          </NavLink>
        ))}
      </nav>
    </aside>
  )
}

export default Sidebar
