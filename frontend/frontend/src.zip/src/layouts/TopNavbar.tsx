import React from 'react'

export const TopNavbar: React.FC = () => {
  return (
    <div className="w-full flex items-center justify-between px-4 py-3 border-b border-gray-200 bg-white/5">
      <div className="flex items-center gap-3">
        <h3 className="text-lg font-semibold">Mission Control</h3>
        <span className="text-sm text-gray-500">AI CRM Ops</span>
      </div>
      <div className="flex items-center gap-3">
        <button className="px-3 py-1 rounded-md bg-gray-100 text-sm">New</button>
        <div className="w-8 h-8 rounded-full bg-gray-200" />
      </div>
    </div>
  )
}

export default TopNavbar
