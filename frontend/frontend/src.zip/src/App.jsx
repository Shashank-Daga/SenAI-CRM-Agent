import React from 'react'
import { Routes, Route } from 'react-router-dom'
import DashboardLayout from './layouts/DashboardLayout'
import InboxPage from './pages/Inbox'
import ThreadPage from './pages/Thread'
import AnalyticsPage from './pages/Analytics'

function App() {
  return (
    <Routes>
      <Route path="/" element={<DashboardLayout><InboxPage /></DashboardLayout>} />
      <Route path="/inbox" element={<DashboardLayout><InboxPage /></DashboardLayout>} />
      <Route path="/analytics" element={<DashboardLayout><AnalyticsPage /></DashboardLayout>} />
      <Route path="/thread/:email" element={<DashboardLayout><ThreadPage /></DashboardLayout>} />
      <Route path="*" element={<DashboardLayout><InboxPage /></DashboardLayout>} />
    </Routes>
  )
}

export default App
