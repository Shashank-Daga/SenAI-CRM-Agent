import { apiClient, ApiResponse } from './client'
import { EmailItem, ThreadDetails, SagencyAnalytics, RagContext } from '../types'

export const fetchEmails = async (query?: string): Promise<EmailItem[]> => {
  const response = await apiClient.get<ApiResponse<EmailItem[]>>('/emails', {
    params: { q: query },
  })
  return response.data.data
}

export const fetchThread = async (contactEmail: string): Promise<ThreadDetails> => {
  const response = await apiClient.get<ApiResponse<ThreadDetails>>(`/threads/${encodeURIComponent(contactEmail)}`)
  return response.data.data
}

export const fetchSentimentTrend = async (): Promise<SagencyAnalytics> => {
  const response = await apiClient.get<ApiResponse<SagencyAnalytics>>('/analytics/sentiment-trend')
  return response.data.data
}

export const fetchCategoryBreakdown = async (): Promise<SagencyAnalytics> => {
  const response = await apiClient.get<ApiResponse<SagencyAnalytics>>('/analytics/category-breakdown')
  return response.data.data
}

export const runDryAgent = async (emailId: string): Promise<unknown> => {
  const response = await apiClient.post<ApiResponse<unknown>>(`/agent/dry-run/${encodeURIComponent(emailId)}`)
  return response.data.data
}

export const executeAgent = async (emailId: string): Promise<unknown> => {
  const response = await apiClient.post<ApiResponse<unknown>>(`/agent/execute/${encodeURIComponent(emailId)}`)
  return response.data.data
}

export const searchRag = async (query: string): Promise<RagContext[]> => {
  const response = await apiClient.get<ApiResponse<RagContext[]>>('/rag/search', {
    params: { q: query },
  })
  return response.data.data
}

export const fetchReputation = async (company: string): Promise<unknown> => {
  const response = await apiClient.get<ApiResponse<unknown>>('/intelligence/reputation', {
    params: { company },
  })
  return response.data.data
}
