import React, { useState } from 'react'
import { useParams } from 'react-router-dom'
import { useThread } from '../hooks/useThread'
import PageHeader from '../components/ui/PageHeader'
import LoadingSkeleton from '../components/ui/LoadingSkeleton'
import EmptyState from '../components/ui/EmptyState'
import EmailContent from '../components/EmailContent'
import ThreadTimeline from '../components/ThreadTimeline'
import ContactProfileCard from '../components/ContactProfileCard'
import AgentReasoningPanel from '../components/AgentReasoningPanel'
import RagContextPanel from '../components/RagContextPanel'
import WebIntelligencePanel from '../components/WebIntelligencePanel'
import ActionToolbar from '../components/ActionToolbar'

export const ThreadPage: React.FC = () => {
  const { email } = useParams<{ email: string }>()
  const { data: thread, isLoading, isError } = useThread(email || '')
  const [isProcessing, setIsProcessing] = useState(false)

  if (!email) {
    return <EmptyState title="No thread selected" description="Select an email from the inbox to view the thread." />
  }

  if (isLoading) {
    return <LoadingSkeleton rows={8} />
  }

  if (isError || !thread) {
    return <EmptyState title="Error loading thread" description="Failed to load thread details. Please try again." />
  }

  const handleDryAgent = async () => {
    setIsProcessing(true)
    try {
      // API call would go here
      console.log('Running dry agent...')
    } finally {
      setIsProcessing(false)
    }
  }

  const handleExecuteAgent = async () => {
    setIsProcessing(true)
    try {
      // API call would go here
      console.log('Executing agent...')
    } finally {
      setIsProcessing(false)
    }
  }

  const handleEscalate = async () => {
    setIsProcessing(true)
    try {
      // API call would go here
      console.log('Escalating...')
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <div className="flex flex-col h-screen">
      <PageHeader title="Thread Workspace" subtitle={`Conversation with ${thread.contact.email}`} />

      <div className="flex-1 overflow-auto grid grid-cols-3 gap-4">
        {/* LEFT PANEL */}
        <div className="col-span-1 overflow-y-auto">
          <EmailContent email={{
            id: thread.messages[0]?.id || '',
            sender: thread.contact.email,
            subject: 'Thread Subject',
            category: 'Support',
            urgency: 'High',
            sentiment: 'Neutral',
            timestamp: thread.messages[0]?.timestamp || new Date().toISOString(),
            escalation: false,
            needs_human: false,
            auto_replied: false,
            spam: false,
            thread_id: '',
          }} />
        </div>

        {/* CENTER PANEL */}
        <div className="col-span-1 overflow-y-auto">
          <ThreadTimeline messages={thread.messages} />
        </div>

        {/* RIGHT PANEL */}
        <div className="col-span-1 overflow-y-auto space-y-4">
          <ContactProfileCard contact={thread.contact} />
          <AgentReasoningPanel steps={thread.agent_reasoning} />
          <RagContextPanel contexts={thread.rag_context} />
          <WebIntelligencePanel data={thread.contact.web_intelligence} />
        </div>
      </div>

      {/* ACTION TOOLBAR */}
      <ActionToolbar
        onDryAgent={handleDryAgent}
        onExecuteAgent={handleExecuteAgent}
        onEscalate={handleEscalate}
        isLoading={isProcessing}
      />
    </div>
  )
}

export default ThreadPage
