import React, { useMemo } from 'react'
import { Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid, Legend, Cell, BarChart, Bar } from 'recharts'
import PageHeader from '../components/ui/PageHeader'
import LoadingSkeleton from '../components/ui/LoadingSkeleton'
import EmptyState from '../components/ui/EmptyState'
import { useAnalytics } from '../hooks/useAnalytics'
import { DashboardGrid } from '../components/analytics/DashboardGrid'
import { ChartCard } from '../components/analytics/ChartCard'
import { MetricCard } from '../components/analytics/MetricCard'
import { TrendBadge } from '../components/analytics/TrendBadge'
import { CategorySegment } from '../types'

const categoryColors = ['#4f46e5', '#0ea5e9', '#22c55e', '#f59e0b', '#ec4899', '#f97316', '#64748b']

export const AnalyticsPage: React.FC = () => {
  const { data, isLoading, isError } = useAnalytics()

  const sentimentData = data?.sentimentTrend ?? []
  const categoryData = data?.categoryBreakdown ?? []
  const escalationMetrics = data?.escalationMetrics
  const automationMetrics = data?.automationMetrics
  const atRiskAccounts = data?.atRiskAccounts ?? []

  const categoryChartData = useMemo(() => {
    const categories: CategorySegment[] = [
      { category: 'Complaint', count: 0 },
      { category: 'Billing', count: 0 },
      { category: 'Legal', count: 0 },
      { category: 'Compliance', count: 0 },
      { category: 'Inquiry', count: 0 },
      { category: 'Spam', count: 0 },
      { category: 'Other', count: 0 },
    ]
    const map = new Map(categories.map((item) => [item.category, item]))
    categoryData.forEach((segment) => {
      const existing = map.get(segment.category)
      if (existing) {
        existing.count = segment.count
      }
    })
    return Array.from(map.values())
  }, [categoryData])

  const hasMetrics = Boolean(data && (categoryData.length > 0 || sentimentData.length > 0 || escalationMetrics || automationMetrics || atRiskAccounts.length > 0))

  return (
    <div>
      <PageHeader title="Analytics Dashboard" subtitle="Operational analytics for sentiment, escalations, automation, and account risk." />

      {isLoading && <LoadingSkeleton rows={8} />}
      {isError && <EmptyState title="Analytics unavailable" description="Unable to load analytics data. Try refreshing the page." />}
      {!isLoading && !isError && !hasMetrics && (
        <EmptyState title="No analytics data" description="No operational analytics are available at this time." />
      )}

      {!isLoading && !isError && hasMetrics && (
        <div className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <MetricCard
              title="Escalation Rate"
              value={escalationMetrics?.escalated !== undefined ? `${escalationMetrics.escalated}%` : '—'}
              description="Share of tickets currently escalated"
            />
            <MetricCard
              title="Human review"
              value={escalationMetrics?.humanReviewPct !== undefined ? `${escalationMetrics.humanReviewPct}%` : '—'}
              description="Requests flagged for manual handling"
            />
            <MetricCard
              title="Auto-reply rate"
              value={automationMetrics?.autoReplyRate !== undefined ? `${automationMetrics.autoReplyRate}%` : '—'}
              description="Automated replies sent from the system"
            />
            <MetricCard
              title="At-risk accounts"
              value={atRiskAccounts.length}
              description="Accounts with elevated churn or negative sentiment"
              highlight
            />
          </div>

          <DashboardGrid>
            <div className="xl:col-span-8">
              <ChartCard title="Sentiment trend" subtitle="Positive, neutral, and negative volume over time">
                {sentimentData.length === 0 ? (
                  <EmptyState title="No trend data" description="Sentiment trend data is unavailable." />
                ) : (
                  <ResponsiveContainer width="100%" height={320}>
                    <LineChart data={sentimentData} margin={{ top: 8, right: 20, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                      <XAxis dataKey="timestamp" tick={{ fill: '#64748b', fontSize: 12 }} tickLine={false} axisLine={false} />
                      <YAxis tick={{ fill: '#64748b', fontSize: 12 }} tickLine={false} axisLine={false} />
                      <Tooltip formatter={(value: number | string) => [value, '']} />
                      <Legend verticalAlign="top" height={32} />
                      <Line type="monotone" dataKey="positive" name="Positive" stroke="#22c55e" strokeWidth={3} dot={false} />
                      <Line type="monotone" dataKey="neutral" name="Neutral" stroke="#0ea5e9" strokeWidth={3} dot={false} />
                      <Line type="monotone" dataKey="negative" name="Negative" stroke="#ef4444" strokeWidth={3} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                )}
              </ChartCard>
            </div>

            <div className="xl:col-span-4">
              <ChartCard title="Category breakdown" subtitle="Volume by customer issue type">
                {categoryChartData.length === 0 ? (
                  <EmptyState title="No category data" description="Category analytics are unavailable." />
                ) : (
                  <ResponsiveContainer width="100%" height={320}>
                    <PieChart>
                      <Pie
                        data={categoryChartData}
                        dataKey="count"
                        nameKey="category"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={4}
                        label={({ name, percent }) => `${name} ${Math.round(percent * 100)}%`}
                      >
                        {categoryChartData.map((entry, idx) => (
                          <Cell key={entry.category} fill={categoryColors[idx % categoryColors.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value: number) => [`${value}`, 'Tickets']} />
                    </PieChart>
                  </ResponsiveContainer>
                )}
              </ChartCard>
            </div>

            <div className="xl:col-span-6">
              <ChartCard title="Escalation metrics" subtitle="Escalated cases vs resolved workflow performance">
                {!escalationMetrics ? (
                  <EmptyState title="No escalation metrics" description="Escalation KPI data is unavailable." />
                ) : (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="rounded-3xl border border-gray-200 bg-slate-50 p-4">
                        <p className="text-sm text-slate-500">Escalated</p>
                        <p className="mt-2 text-3xl font-semibold text-slate-900">{escalationMetrics.escalated}%</p>
                      </div>
                      <div className="rounded-3xl border border-gray-200 bg-slate-50 p-4">
                        <p className="text-sm text-slate-500">Resolved</p>
                        <p className="mt-2 text-3xl font-semibold text-slate-900">{escalationMetrics.resolved}%</p>
                      </div>
                    </div>
                    <ResponsiveContainer width="100%" height={180}>
                      <BarChart data={[{ name: 'Escalation', value: escalationMetrics.escalated }, { name: 'Resolved', value: escalationMetrics.resolved }] }>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                        <XAxis dataKey="name" tick={{ fill: '#64748b', fontSize: 12 }} axisLine={false} tickLine={false} />
                        <YAxis tick={{ fill: '#64748b', fontSize: 12 }} axisLine={false} tickLine={false} />
                        <Tooltip formatter={(value: number) => [`${value}%`, '']} />
                        <Bar dataKey="value" fill="#6366f1" radius={[8, 8, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </ChartCard>
            </div>

            <div className="xl:col-span-6">
              <ChartCard title="Automation metrics" subtitle="AI automation health and execution performance">
                {!automationMetrics ? (
                  <EmptyState title="No automation metrics" description="Automation KPI data is unavailable." />
                ) : (
                  <div className="grid gap-4 sm:grid-cols-3">
                    <div className="rounded-3xl border border-gray-200 bg-slate-50 p-4">
                      <p className="text-sm text-slate-500">Auto-reply rate</p>
                      <p className="mt-2 text-3xl font-semibold text-slate-900">{automationMetrics.autoReplyRate}%</p>
                    </div>
                    <div className="rounded-3xl border border-gray-200 bg-slate-50 p-4">
                      <p className="text-sm text-slate-500">Dry-run count</p>
                      <p className="mt-2 text-3xl font-semibold text-slate-900">{automationMetrics.dryRunCount}</p>
                    </div>
                    <div className="rounded-3xl border border-gray-200 bg-slate-50 p-4">
                      <p className="text-sm text-slate-500">Execution count</p>
                      <p className="mt-2 text-3xl font-semibold text-slate-900">{automationMetrics.executionCount}</p>
                    </div>
                  </div>
                )}
              </ChartCard>
            </div>

            <div className="xl:col-span-12">
              <ChartCard title="At-risk accounts" subtitle="Accounts with churn risk and unresolved escalations">
                {atRiskAccounts.length === 0 ? (
                  <EmptyState title="No at-risk accounts" description="No accounts currently meet the at-risk criteria." />
                ) : (
                  <div className="grid gap-4 md:grid-cols-2">
                    {atRiskAccounts.map((account) => (
                      <div key={account.company} className="rounded-3xl border border-gray-200 bg-slate-50 p-4">
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <p className="text-sm font-semibold text-slate-900">{account.company}</p>
                            <p className="mt-1 text-xs uppercase tracking-[0.16em] text-slate-500">Churn risk</p>
                            <p className="mt-1 text-lg font-semibold text-slate-800">{account.churnRisk}</p>
                          </div>
                          <TrendBadge
                            value={`${account.negativeSentimentTrend}%`}
                            trend={account.negativeSentimentTrend > 0 ? 'negative' : account.negativeSentimentTrend < 0 ? 'positive' : 'neutral'}
                            label={`${account.negativeSentimentTrend > 0 ? 'Worsening' : account.negativeSentimentTrend < 0 ? 'Improving' : 'Stable'}`}
                          />
                        </div>
                        <div className="mt-4 flex items-center justify-between rounded-2xl bg-white p-3 text-sm text-slate-600">
                          <span>Unresolved escalations</span>
                          <span className="font-semibold text-slate-900">{account.unresolvedEscalations}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ChartCard>
            </div>
          </DashboardGrid>
        </div>
      )}
    </div>
  )
}

export default AnalyticsPage
