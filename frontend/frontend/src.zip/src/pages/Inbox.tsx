import React, { useMemo, useState } from 'react'
import { useEmails } from '../hooks/useEmails'
import PageHeader from '../components/ui/PageHeader'
import SearchBar from '../components/ui/SearchBar'
import FilterTabs from '../components/ui/FilterTabs'
import LoadingSkeleton from '../components/ui/LoadingSkeleton'
import EmptyState from '../components/ui/EmptyState'
import InboxTable from '../components/InboxTable'
import { EmailItem } from '../types'

const tabs = [
  { key: 'all', label: 'All' },
  { key: 'needs_human', label: 'Needs Human' },
  { key: 'escalated', label: 'Escalated' },
  { key: 'auto_replied', label: 'Auto-Replied' },
  { key: 'spam', label: 'Spam' },
]

export const InboxPage: React.FC = () => {
  const [search, setSearch] = useState('')
  const [active, setActive] = useState('all')
  const { data, isLoading, isError } = useEmails(search)

  const filtered = useMemo(() => {
    if (!data) return []
    switch (active) {
      case 'needs_human':
        return data.filter((e: EmailItem) => e.needs_human)
      case 'escalated':
        return data.filter((e: EmailItem) => e.escalation)
      case 'auto_replied':
        return data.filter((e: EmailItem) => e.auto_replied)
      case 'spam':
        return data.filter((e: EmailItem) => e.spam)
      default:
        return data
    }
  }, [data, active])

  return (
    <div>
      <PageHeader title="Mission Control — Inbox" subtitle="Monitor incoming customer emails and triage">
        <div className="flex items-center gap-2">
          <SearchBar value={search} onChange={setSearch} />
        </div>
      </PageHeader>

      <div className="mb-4 flex items-center justify-between">
        <FilterTabs tabs={tabs} active={active} onChange={setActive} />
        <div className="flex items-center gap-3">
          <button className="px-3 py-1 rounded-md bg-gray-100 text-sm">Refresh</button>
        </div>
      </div>

      {isLoading && <LoadingSkeleton />}
      {isError && <EmptyState title="Error" description="Failed to load emails" />}
      {!isLoading && filtered.length === 0 && <EmptyState title="No emails" description="No emails match the current filters." />}

      {!isLoading && filtered.length > 0 && (
        <div>
          <InboxTable emails={filtered} />
        </div>
      )}
    </div>
  )
}

export default InboxPage
