import { useQuery } from '@tanstack/react-query'
import { fetchSentimentTrend, fetchCategoryBreakdown } from '../api/emails'
import { SagencyAnalytics } from '../types'

export const useAnalytics = () => {
  return useQuery<SagencyAnalytics, Error>({
    queryKey: ['analytics'],
    queryFn: async () => {
      const [sentimentTrend, categoryBreakdown] = await Promise.all([
        fetchSentimentTrend(),
        fetchCategoryBreakdown(),
      ])

      return {
        sentimentTrend: sentimentTrend.sentimentTrend,
        categoryBreakdown: categoryBreakdown.categoryBreakdown,
        escalationMetrics: sentimentTrend.escalationMetrics ?? categoryBreakdown.escalationMetrics,
        automationMetrics: sentimentTrend.automationMetrics ?? categoryBreakdown.automationMetrics,
        atRiskAccounts: sentimentTrend.atRiskAccounts ?? categoryBreakdown.atRiskAccounts ?? [],
      }
    },
    refetchInterval: 30000,
    staleTime: 20000,
  })
}
